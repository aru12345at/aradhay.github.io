# Aradhay Tabhane — Personal Website

## How to open it
1. Keep `index.html` and `hero.png` in the same folder.
2. Open `index.html` in Chrome or another browser.

No internet connection or extra software is required for the basic site.
